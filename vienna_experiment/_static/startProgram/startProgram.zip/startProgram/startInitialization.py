# Importieren Sie die Module tkinter, webbrowser und requests
import tkinter as tk
import tkinter.filedialog as fd
import webbrowser
import requests
import time
import datetime
import random
from tobii_timescale import startTracking
#import tobii_timescale as startTimescaleDBConnection

mappingID = None

#Schema um deinProgramm aus tobii_timescale.py zu starten + file_path zur License Datei,da die ja an den einzelnen Pcs verschieden ist.
def startTimescaleDBConnection(file_path, mappingID): 
    # Try to start the tracking and catch any errors try: 
    try:
        startTracking(file_path, mappingID) 
        # Update the label with a success message 
        label.config(
        text=f"Tracking started successfully with mapping ID {mappingID}"
        )
    except Exception as e: 
        # Update the label with an error message 
        label.config(text=f"Error: {e}")
        
        


def generate_unique_id():
    # Erhalten Sie das aktuelle Datum und die Uhrzeit als String im Format YYYYMMDDHHMMSS
    date_time = datetime.datetime.now().strftime("%Y%m%d%H%M%S")

    # Erzeugen Sie eine zufällige Zahl zwischen 0 und 9999 als String mit vier Stellen
    random_number = str(random.randint(0, 9999)).zfill(4)

    # Verbinden Sie das Datum, die Uhrzeit und die zufällige Zahl mit einem Bindestrich
    unique_id = date_time + "-" + random_number

    # Geben Sie die eindeutige ID zurück
    return str(unique_id)

    
# Definieren Sie eine Funktion, die beim Klick auf den Button aufgerufen wird
def button_clicked(input_id):
    
    # Warten Sie, bis der Benutzer eine URL eingegeben hat
    url = f"http://localhost:8000/InitializeParticipant/{input_id}"

    webbrowser.open(url)

    mappingID= generate_unique_id()
    
    # Senden Sie einen GET-Request an die Website mit dem String als Parameter
    response = requests.get(url)

    # Warten Sie 5 Sekunden
    time.sleep(2)

    # Lesen Sie den neuen Link der Website aus
    new_url = response.url
    webbrowser.open(f"{new_url}?string={mappingID}")
    # Update the label with a message that the initialization is done
    label.config(text=f"Initialization done. Mapping ID is {mappingID}")
    

    
    
def file_clicked():

    # Öffnen Sie einen Dateiauswahldialog und speichern Sie den Pfad zur ausgewählten Datei
    file_path = fd.askopenfilename()

    # Erstellen Sie einen dritten Button, der die Funktion startTimescaleDBConnection aufruft
    button3 = tk.Button(window, text='Start TimescaleDB Connection', command=lambda: startTimescaleDBConnection(file_path))
    button3.pack()


# Erstellen Sie ein tkinter-Fenster
window = tk.Tk()
window.title("Initialisierung")

window_width = 400 
window_height = 300 
screen_width = window.winfo_screenwidth() 
screen_height = window.winfo_screenheight() 
x = (screen_width // 2) - (window_width // 2) 
y = (screen_height // 2) - (window_height // 2) 
window.geometry(f"{window_width}x{window_height}+{x}+{y}")
entry = tk.Entry(window, width=40) 
entry.insert(0, 'Enter Init Participant ID')
entry.pack()
# Erstellen Sie einen Button, der die Funktion button_clicked aufruft
button = tk.Button(window, text='Init', command=lambda: button_clicked(entry.get())) 
button2 = tk.Button(window, text='Choose File', command=file_clicked) 
button.pack(pady=10) 
button2.pack(pady=10) 

#Create a label to display messages to the user
label = tk.Label(window, text='Please enter an ID and choose a file') 
label.pack(pady=10) 
#Create a text widget to display the console outputs
console = tk.Text(window, width=40, height=10) 
console.pack(pady=10) # Add some vertical space

# Starten Sie die GUI-Schleife
window.mainloop()
